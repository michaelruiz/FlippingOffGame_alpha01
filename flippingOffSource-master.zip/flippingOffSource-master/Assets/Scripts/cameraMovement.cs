﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraMovement : MonoBehaviour {

    public float borderBuffer;
    public float cameraCursorMoveSpeed;
    public float cameraArrowMoveSpeed;
    public float zoomMax;
    public float zoomMin;
    public float zoomSpeed;
    private float screenWidth;
    private float screenHeight;
    private float moveX;
    private float moveY;
    private float zoom;
    private float zoomInOut;
    Vector2 cameraPosition;
    
    // Use this for initialization
	void Start () {
        screenWidth = Screen.width;
        screenHeight = Screen.height;
        cameraPosition = transform.position;
        zoom = 5;

    }
	
	// Update is called once per frame
	void Update () {

        //Moving the screen when using arrow keys
        moveX = Input.GetAxis("Horizontal");
        moveY = Input.GetAxis("Vertical");

        cameraPosition.x += cameraArrowMoveSpeed * moveX * Time.deltaTime;
        cameraPosition.y += cameraArrowMoveSpeed * moveY * Time.deltaTime;

        //Moving the screen when mouse on edge
        if (Input.mousePosition.x > screenWidth - borderBuffer)
        {
            cameraPosition.x += cameraCursorMoveSpeed * Time.deltaTime;
        }
        if (Input.mousePosition.x < borderBuffer)
        {
            cameraPosition.x -= cameraCursorMoveSpeed * Time.deltaTime;
        }
        if (Input.mousePosition.y > screenHeight - borderBuffer)
        {
            cameraPosition.y += cameraCursorMoveSpeed * Time.deltaTime;
        }
        if (Input.mousePosition.y < borderBuffer)
        {
            cameraPosition.y -= cameraCursorMoveSpeed * Time.deltaTime;
        }

        transform.position = cameraPosition;
       
        //Zooming in and out using the mouse wheel with max and min values
        zoomInOut = Input.GetAxis("Mouse ScrollWheel");
        zoom -= zoomInOut * zoomSpeed * Time.deltaTime;
        zoom = Mathf.Clamp(zoom, zoomMin, zoomMax);
        Camera.main.orthographicSize = zoom;

    }
}
