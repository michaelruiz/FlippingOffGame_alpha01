﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class buttonManager : MonoBehaviour {

    public GameObject mainMenu;
    public GameObject optionsMenu;

    private void Start()
    {
        optionsMenu.gameObject.SetActive(false);
    }

    public void startBtn()
    {
        SceneManager.LoadScene("Level");

    }

    public void optionsBtn()
    {
        mainMenu.gameObject.SetActive(false);
        optionsMenu.gameObject.SetActive(true);
        Debug.Log("You Clicked");
    }

    public void quitBtn()
    {
        Application.Quit();
    }

    public void optionsBackBtn()
    {
        mainMenu.gameObject.SetActive(true);
        optionsMenu.gameObject.SetActive(false);
        Debug.Log("You Clicked");
    }
}
