﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class characterController : MonoBehaviour
{

    public float charSpeed;
    public float inaccuracyRange;
    private float moveHorizontal;
    private float moveVertical;
    private float distance;
    private bool isMoving = true;
    Vector2 targetPosition;
    Vector2 currentPosition;
    Animator anim;
    SpriteRenderer sprRen;



    // Use this for initialization
    void Start()
    {
        anim = GetComponent<Animator>();
        sprRen = GetComponent<SpriteRenderer>();
        targetPosition = transform.position;
        currentPosition = transform.position;
    }

    void Update()
    {

        //Checks to find where the mouse has been clicked
        if (Input.GetMouseButtonDown(0))
        {
            targetPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position = Vector2.MoveTowards(transform.position, targetPosition, Time.deltaTime * charSpeed);
            isMoving = true;

            Debug.Log(targetPosition);
        }

        //Moves the character towards the vectors with animation
        if (isMoving == true)
        {
            transform.position = Vector2.MoveTowards(transform.position, targetPosition, Time.deltaTime * charSpeed);
            currentPosition = transform.position;

            if (targetPosition.x > currentPosition.x)
            {
                anim.Play("playerRun");
                sprRen.flipX = false;
            }
            else if (targetPosition.x < currentPosition.x)
            {
                sprRen.flipX = true;
                anim.Play("playerRun");
            }
            else if (targetPosition != currentPosition)
            {
                anim.Play("playerRun");
            }

            distance = Vector2.Distance(currentPosition, targetPosition);
            Debug.Log(distance);

            if (distance < inaccuracyRange)
            {
                anim.Play("playerIdle");
                isMoving = false;
                Debug.Log(distance);
            }

        }

    }
}
