﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System;

public class keepingScore : MonoBehaviour {
    public static double homeScore = 4;



    // Use this for initialization
    void Start ()
    {
        print(homeScore);
        homeScore.ToString();
    }

    void OnGUI()
    {
        GUI.Label(new Rect(10, 10, 100, 20), homeScore.ToString());
    }
    // Update is called once per frame
    void Update () {
		
	}
}
